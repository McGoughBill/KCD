import os
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import nn, einsum
import numpy as np

# code inspired by vicreg and taken from https://github.com/facebookresearch/vicreg/blob/main/main_vicreg.py#L239

def off_diagonal(x):
    n, m = x.shape
    assert n == m
    return x.flatten()[:-1].view(n - 1, n + 1)[:, 1:].flatten()


class DomainAdaptationLoss(nn.Module):
    def __init__(self, l2_weight = 0, cce_weight = 0, cos_weight = 0, out_dim= 2):
        super(DomainAdaptationLoss, self).__init__()
        self.mse = nn.MSELoss()
        self.cos = nn.CosineSimilarity(dim=-1)
        self.cce = nn.CrossEntropyLoss()
        self.huber = nn.SmoothL1Loss()
        self.l2 = nn.MSELoss()
        self.kld = nn.KLDivLoss()
        self.l2_weight = l2_weight
        self.cce_weight = cce_weight
        self.cos_weight = cos_weight
        self.out_dim = out_dim

    def normalize(self, z):
        mag = torch.linalg.vector_norm(z, dim=-1, keepdim=True)
        return z / mag

    def forward(self, ne_log_list,ne_cls_features,enhancement_pred,
                ce_log_list,ce_cls_features,enhancement_label):
        cce_loss, l2_loss, cos_loss = 0, 0, 0
        if self.cce_weight>0:
            scale_weights = 2 ** np.arange(len(ne_log_list))
            scale_weights = scale_weights / scale_weights.sum()
            for (ne_pred,ce_pred) in zip(ne_log_list,ce_log_list):
                cce_loss += self.cce(ne_pred, torch.argmax(ce_pred, dim=1))*scale_weights

        if self.l2_weight>0:
            l2_loss = self.l2(enhancement_pred, enhancement_label)

        if self.cos_weight>0:
            cos_loss = (1 - self.cos(self.normalize(ne_cls_features), self.normalize(ce_cls_features))).mean()

        loss = cce_loss*self.cce_weight + l2_loss*self.l2_weight + cos_loss*self.cos_weight

        return loss, cce_loss, l2_loss, cos_loss


class LatentSimilarityLoss(nn.Module):
    def __init__(self, l2_weight = 0, l1_weight = 0, cce_weight = 0, cos_weight = 0,
                 var_loss_weight = 0, cov_loss_weight=0,clip_loss_weight=0,out_dim= 2):
        super(LatentSimilarityLoss, self).__init__()
        self.mse = nn.MSELoss()
        self.cos = nn.CosineSimilarity(dim=-1)
        self.cce = nn.CrossEntropyLoss()
        self.softmax = nn.Softmax(dim=1)
        self.temperature = np.exp(0.07)
        self.mse_weight = 0.01
        self.cos_weight = 1
        self.huber = nn.SmoothL1Loss()
        self.l2 = nn.MSELoss()
        self.kld = nn.KLDivLoss()
        self.l2_weight = l2_weight
        self.l1_weight = l1_weight
        self.cce_weight = cce_weight
        self.cos_weight = cos_weight
        self.var_loss_weight = var_loss_weight # encourages variance in features across samples
        self.cov_loss_weight = cov_loss_weight # discourages covariance between features in each samples
        self.clip_loss_weight = clip_loss_weight
        self.out_dim = out_dim

    def normalize(self, z):
        mag = torch.linalg.vector_norm(z, dim=-1, keepdim=True)
        return z / mag

    def forward(self, z1, z2):
        b,d,x,y,z = z1.shape

        # reshaped_z1 = z1.view(b,d,-1).swapaxes(1,2)
        # reshaped_z2 = z2.view(b,d,-1).swapaxes(1,2)
        #
        # s_ptd = self.softmax(reshaped_z1)
        # t_ptd = self.softmax(reshaped_z2)
        # self.symmetric_cce = (self.cce(s_ptd, t_ptd) + self.cce(t_ptd, s_ptd))/2
        #
        # return self.symmetric_cce/(x*y*z)

        reshaped_z1 = z1.view(b, d, -1).swapaxes(1,2).reshape(-1,d)#  (b*x*y*z, d)
        reshaped_z2 = z2.view(b, d, -1).swapaxes(1,2).reshape(-1,d) # (b*x*y*z, d)

        loss = 0

        if d == self.out_dim:
            if self.cce_weight>0:
                amax_z1 = torch.argmax(reshaped_z1, dim=1)
                amax_z2 = torch.argmax(reshaped_z2, dim=1)
                symm_cce = (self.cce(reshaped_z1, amax_z2) + self.cce(reshaped_z2, amax_z1)) / 2
                loss += symm_cce*self.cce_weight
        else:
            if self.l2_weight>0:
                l2 = self.l2(reshaped_z1, reshaped_z2)
                loss += l2*self.l2_weight
            if self.l1_weight>0:
                l1 = self.huber(reshaped_z1, reshaped_z2)
                loss += l1*self.l1_weight
            if self.cos_weight>0:
                cos = (1 - self.cos(self.normalize(reshaped_z1), self.normalize(reshaped_z2))).mean()
                loss += (cos)*self.cos_weight
            if self.var_loss_weight>0:
                #Variance: a hinge loss to maintain the standard deviation (over a batch) of each variable of
                # the embedding above a given threshold (1 in this example). This term forces the embedding vectors of samples
                # within a batch to be different
                x = reshaped_z1 - reshaped_z1.mean(dim=0)
                y = reshaped_z2 - reshaped_z2.mean(dim=0)

                std_x = torch.sqrt(x.var(dim=0) + 0.0001) # find variance across dimension n (b*x*y*z, d)
                std_y = torch.sqrt(y.var(dim=0) + 0.0001)
                # print(std_x.shape)
                # print('Mean inter-sample std deviation: {:.5f}'.format(std_x.mean() + std_y.mean()))

                var_loss = torch.mean(F.relu(1 - std_x)) / 2 + torch.mean(F.relu(1 - std_y)) / 2
                # print(var_loss)
                loss += torch.clamp(var_loss,0,1)*self.var_loss_weight
                if self.cov_loss_weight>0:
                    cov_x = (x.T @ x) / (x.shape[0] - 1)
                    cov_y = (y.T @ y) / (x.shape[0] - 1)
                    # print(cov_x.shape)
                    # print('Mean intra-sample covariance: {:.5f}'.format(off_diagonal(cov_x).mean() + off_diagonal(cov_y).mean()))
                    cov_loss = off_diagonal(cov_x).pow(2).mean() + off_diagonal(cov_y).pow(2).mean()
                    # print(cov_loss)
                    loss += torch.clamp(cov_loss,0,1)*self.cov_loss_weight
        return loss / (d**0.333)

class LatentSimilarityLoss_resnet(nn.Module):
    def __init__(self, l2_weight = 0, l1_weight = 0, cce_weight = 0, cos_weight = 0,
                 var_loss_weight = 0, cov_loss_weight=0,out_dim= 2,clip_loss_weight=0):
        super(LatentSimilarityLoss_resnet, self).__init__()
        self.mse = nn.MSELoss()
        self.cos = nn.CosineSimilarity(dim=-1)
        self.cce = nn.CrossEntropyLoss()
        self.softmax = nn.Softmax(dim=1)
        self.temperature = 0.07
        self.mse_weight = 0.01
        self.cos_weight = 1
        self.huber = nn.SmoothL1Loss()
        self.l2 = nn.MSELoss()
        self.kld = nn.KLDivLoss()
        self.l2_weight = l2_weight
        self.l1_weight = l1_weight
        self.cce_weight = cce_weight
        self.cos_weight = cos_weight
        self.var_loss_weight = var_loss_weight # encourages variance in features across samples
        self.cov_loss_weight = cov_loss_weight # discourages covariance between features in each samples
        self.clip_loss_weight = clip_loss_weight
        self.out_dim = out_dim

    def normalize(self, z):
        mag = torch.linalg.vector_norm(z, dim=-1, keepdim=True)
        return z / mag

    def forward(self, reshaped_z1, reshaped_z2):
        b,d = reshaped_z1.shape
        loss = 0
        if d == self.out_dim:
            if self.cce_weight>0:
                amax_z1 = torch.argmax(reshaped_z1, dim=1)
                amax_z2 = torch.argmax(reshaped_z2, dim=1)
                symm_cce = (self.cce(reshaped_z1, amax_z2) + self.cce(reshaped_z2, amax_z1)) / 2
                loss += symm_cce*self.cce_weight
        else:
            if self.clip_loss_weight>0:
                # calculate multimodal embeddings
                normalised_similarity = (F.normalize(reshaped_z1, p=2, dim=1) @ F.normalize(reshaped_z2, p=2, dim=1).T) / self.temperature
                labels = torch.arange(b).to(reshaped_z1.device)
                symm_cce = (F.cross_entropy(normalised_similarity, labels,reduction='mean')
                            + F.cross_entropy(normalised_similarity.T, labels,reduction='mean'))
                loss += symm_cce*self.clip_loss_weight
            if self.l2_weight>0:
                l2 = self.l2(reshaped_z1, reshaped_z2)
                loss += l2*self.l2_weight
            if self.l1_weight>0:
                l1 = self.huber(reshaped_z1, reshaped_z2)
                loss += l1*self.l1_weight
            if self.cos_weight>0:
                cos = (1 - self.cos(self.normalize(reshaped_z1), self.normalize(reshaped_z2))).mean()
                loss += (cos)*self.cos_weight
            if self.var_loss_weight>0:
                #Variance: a hinge loss to maintain the standard deviation (over a batch) of each variable of
                # the embedding above a given threshold (1 in this example). This term forces the embedding vectors of samples
                # within a batch to be different
                x = reshaped_z1 - reshaped_z1.mean(dim=0)
                y = reshaped_z2 - reshaped_z2.mean(dim=0)

                std_x = torch.sqrt(x.var(dim=0) + 0.0001) # find variance across dimension n (b*x*y*z, d)
                std_y = torch.sqrt(y.var(dim=0) + 0.0001)
                # print(std_x.shape)
                # print('Mean inter-sample std deviation: {:.5f}'.format(std_x.mean() + std_y.mean()))

                var_loss = torch.mean(F.relu(1 - std_x)) / 2 + torch.mean(F.relu(1 - std_y)) / 2
                # print(var_loss)
                loss += torch.clamp(var_loss,0,1)*self.var_loss_weight
                if self.cov_loss_weight>0:
                    cov_x = (x.T @ x) / (x.shape[0] - 1)
                    cov_y = (y.T @ y) / (x.shape[0] - 1)
                    # print(cov_x.shape)
                    # print('Mean intra-sample covariance: {:.5f}'.format(off_diagonal(cov_x).mean() + off_diagonal(cov_y).mean()))
                    cov_loss = off_diagonal(cov_x).pow(2).mean() + off_diagonal(cov_y).pow(2).mean()
                    # print(cov_loss)
                    loss += torch.clamp(cov_loss,0,1)*self.cov_loss_weight
        return loss



class PyramidalLatentSimilarityLoss(nn.Module):
    def __init__(self, l2_weight = 0, l1_weight = 0, cce_weight = 0, cos_weight = 0,
                 var_loss_weight = 0, cov_loss_weight=0, out_dim= 2):
        super(PyramidalLatentSimilarityLoss, self).__init__()
        self.similarity_loss = LatentSimilarityLoss(
            l2_weight = l2_weight,
            l1_weight = l1_weight,
            cce_weight = cce_weight,
            cos_weight = cos_weight,
            var_loss_weight = var_loss_weight,
            cov_loss_weight = cov_loss_weight,
            out_dim = out_dim
        )

    def forward(self, feature_list1, feature_list2):
        loss = 0
        for i in range(len(feature_list1)):
            loss += self.similarity_loss(feature_list1[i], feature_list2[i])
        return loss



if __name__ == "__main__":
    # Test the loss function
    loss = PyramidalLatentSimilarityLoss()

    test_highsim = True

    z1a = torch.randn(4,10)
    z2a = torch.randn(4,10)

    z1b = torch.randn(5,100)
    z2b = torch.randn(5,100)

    z1c = torch.randn(6,1000)
    z2c = torch.randn(6,1000)

    if test_highsim:
        z2a+= z1a*2
        z2b+= z1b*2
        z2c+= z1c*2

    print(loss([z1a,z1b,z1c],[z2a,z2b,z2c]))