import torch
import os
os.environ['OV_DATA_BASE'] ='/bask/projects/p/phwq4930-renal-canc/data/seg_data'
from torch.utils.data import DataLoader
import torch.multiprocessing as mp
torch.multiprocessing.set_sharing_strategy('file_system')
import argparse
import torch.distributed as dist
from datetime import timedelta

from KCD.ne2ceCT.dataloader_SSL import CrossPhaseDataset
from KCD.ne2ceCT.loss_function import LatentSimilarityLoss_resnet as LatentSimilarityLoss
from KCD.ne2ceCT.lr_scheduler import LinearWarmupExponentialDecayScheduler
import matplotlib.pyplot as plt
import torch.optim.lr_scheduler as lr_scheduler
import sys
from fmcib.models import fmcib_model
import gc


def parse_option():
    parser = argparse.ArgumentParser('ne2ceCT pretraining script', add_help=False)

    parser.add_argument('--epochs', type=int, default=1000, help='number of epochs')
    parser.add_argument('--l1_weight', type=float, default=25, help='l1 weight')
    parser.add_argument('--l2_weight', type=float, default=0, help='l2 weight')
    parser.add_argument('--cce_weight', type=float, default=0, help='cce weight')
    parser.add_argument('--cos_weight', type=float, default=0, help='cosine similarity weight')
    parser.add_argument('--var_loss_weight', type=float, default=0.1, help='variance loss weight')
    parser.add_argument('--cov_loss_weight', type=float, default=0.1, help='covariance loss weight')
    parser.add_argument('--clip_loss_weight', type=float, default=0, help='clip loss weight')
    parser.add_argument('--batch_size', type=int, default=4, help='batch size')
    parser.add_argument('--lr_max', type=float, default=0.00005, help='max learning rate')
    parser.add_argument('--loss_gamma', type=float, default=0.99999, help='gamma for learning rate scheduler')
    parser.add_argument('--dist_backend', type=str, default='nccl', help='distributed backend')
    parser.add_argument('--dist_url', type=str, default='env://', help='url used to set up distributed training')
    parser.add_argument('--world_size', type=int, default=1, help='number of nodes for distributed training')
    parser.add_argument('--rank', type=int, default=0, help='node rank for distributed training')
    parser.add_argument('--distributed', action='store_true', help='start distributed training')
    parser.add_argument('--workers', default=16, type=int, help='number of workers')
    parser.add_argument('--ngpus_per_node', default=4, type=int, help='number of gpus per node')
    parser.add_argument('--out_dim', default=2, type=int, help='output dimension')
    parser.add_argument('--spacing', default=1, type=int, help='spacing')
    parser.add_argument('--dist-url', default='tcp://127.0.0.1:23456', type=str, help='distributed url')
    parser.add_argument('--background_threshold', default=0.5, type=float, help='background threshold')

    args = parser.parse_args()
    print('args parsed')

    return args

def main():

    args = parse_option()
    if args.distributed:
        args.ngpus_per_node = torch.cuda.device_count()
        print('Found total gpus', args.ngpus_per_node)
        args.world_size = args.ngpus_per_node * args.world_size
        mp.spawn(main_worker,
                 nprocs=args.ngpus_per_node,
                 args=(args,))
    else:
        main_worker(gpu=0, args=args)

def main_worker(gpu,args):
    if args.distributed:
        torch.multiprocessing.set_start_method('fork', force=True)
    args.gpu = gpu
    if args.distributed:
        args.rank = args.rank * args.ngpus_per_node + gpu
        dist.init_process_group(backend=args.dist_backend,
                                init_method=args.dist_url,
                                world_size=args.world_size,
                                rank=args.rank,
                                timeout=timedelta(300))
    torch.cuda.set_device(args.gpu)
    print(args.rank, ' gpu', args.gpu)
    if args.rank == 0:
        print('Batch size is:', args.batch_size, 'epochs', args.epochs)

    l1_weight = args.l1_weight
    l2_weight = args.l2_weight
    cce_weight = args.cce_weight
    cos_weight = args.cos_weight
    var_loss_weight = args.var_loss_weight
    cov_loss_weight = args.cov_loss_weight
    lr_max = args.lr_max
    loss_gamma = args.loss_gamma
    batch_size = args.batch_size
    epochs = args.epochs
    out_dim = args.out_dim
    spacing = args.spacing
    workers = args.workers
    world_size = args.world_size
    clip_loss_weight = args.clip_loss_weight
    background_threshold = args.background_threshold

    dataset_ne_path = os.path.join(os.environ['OV_DATA_BASE'], 'preprocessed/tciaandcoltea_ncct/1mm_ISBI/')
    dataset_ce_path = os.path.join(os.environ['OV_DATA_BASE'], 'preprocessed/tciaandcoltea_cect/1mm_NMI/')

    assert os.path.exists(dataset_ne_path) and os.path.exists(dataset_ce_path)
    home_path = os.path.join(os.environ['OV_DATA_BASE'], 'ne2ceCT', 'resnet_tciaandcoltea_{}_cancer'.format(spacing))
    ne2ceCT_path = os.path.join(home_path,
                                'l1-{}_l2-{}_var{}_cov{}_cce{}_cos{}_clip{}_{}lr_{}lg_{}bs_{}ep_{}gpus_{}bgt'.format(l1_weight,
                                                                                   l2_weight,
                                                                                   var_loss_weight,
                                                                                   cov_loss_weight,
                                                                                   cce_weight,
                                                                                   cos_weight,
                                                                                   clip_loss_weight,
                                                                                   lr_max,
                                                                                   loss_gamma,
                                                                                   batch_size,
                                                                                   epochs,
                                                                                   world_size,
                                                                                   background_threshold))

    log_path = os.path.join(ne2ceCT_path, 'logs.txt')
    if args.rank == 0:
        if not os.path.exists(ne2ceCT_path):
            os.makedirs(ne2ceCT_path)
        if os.path.exists(log_path):
            os.remove(log_path)

    dataset = CrossPhaseDataset(dataset_ne_path, dataset_ce_path,
                                home_path,
                                device='cuda',
                                is_train=True, patches_per_case=40, patch_size=50,
                                background_threshold=background_threshold,background_value = 0.1)
    if args.rank == 0:
        print(dataset.cases)

    dataset.apply_foldsplit()
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, pin_memory=True, num_workers=workers)

    model_T = fmcib_model().cuda(args.gpu)
    model_S = fmcib_model().cuda(args.gpu)

    model_T.eval()
    model_S.train()

    optimizer = torch.optim.Adam(model_S.parameters(), lr=lr_max / 20, betas=(0.95, 0.9), eps=1e-08,
                                 weight_decay=0.000001)

    scheduler = LinearWarmupExponentialDecayScheduler(optimizer, warmup_epochs=500, lr_max=lr_max,
                                                      decay_rate=loss_gamma)

    loss_func = LatentSimilarityLoss(l1_weight=l1_weight, l2_weight=l2_weight,
                                              cce_weight=cce_weight, cos_weight=cos_weight,
                                              var_loss_weight=var_loss_weight, cov_loss_weight=cov_loss_weight,
                                                clip_loss_weight=clip_loss_weight,
                                              out_dim=out_dim).cuda(args.gpu)
    losses = []
    weight = 0.95
    running_loss = None
    running_val_loss = None
    min_val_loss = 1e6
    for epoch in range(epochs):
        dataloader.dataset.is_train = True
        model_S.train()
        for i, (ne, ce) in enumerate(dataloader):
            # forward
            ne = ne.cuda(args.gpu)
            ce = ce.cuda(args.gpu)
            with torch.no_grad():
                T_features = model_T(ce)
            S_features = model_S(ne)
            loss = loss_func(T_features, S_features)
            sys.stdout.flush()
            dist.all_reduce(loss, op=dist.ReduceOp.AVG)

            # backward
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model_S.parameters(), 1)
            # update weights
            optimizer.step()
            if running_loss is None:
                running_loss = loss.item()
            else:
                running_loss = weight * running_loss + (1 - weight) * loss.item()

            if args.rank == 0:
                print('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f}'.format(epoch + 1, epochs, i + 1, len(dataloader),
                                                                         loss.item()))
            # print like above but with line replacement

            losses.append(running_loss)
            scheduler.step()
        if args.rank == 0:
            train_string = f'Epoch [{epoch + 1}/{epochs}], Step [{i + 1}/{len(dataloader)}], Loss: {running_loss:.4E}, LR: {scheduler.get_last_lr()[0]:.4E}\n'
            with open(log_path, 'a') as f:
                f.write(train_string)

        gc.collect()
        #clear cuda cache
        torch.cuda.empty_cache()

        dataloader.dataset.is_train = False
        if args.rank == 0:
            with torch.no_grad():
                model_S.eval()
                for i, (ne, ce) in enumerate(dataloader):
                    ne = ne.cuda(args.gpu)
                    ce = ce.cuda(args.gpu)
                    T = model_T(ce)
                    S = model_S(ne)
                    loss = loss_func(T, S)
                    if running_val_loss is None:
                        running_val_loss = loss.item()
                    else:
                        running_val_loss = weight * running_val_loss + (1 - weight) * loss.item()
            val_string = f'Val Loss: {running_val_loss:.4E}\n'
            with open(log_path, 'a') as f:
                f.write(val_string)
            if running_val_loss < min_val_loss:
                min_val_loss = running_val_loss
                torch.save(model_S.state_dict(), os.path.join(ne2ceCT_path, 'network_weights'))
                print('Model saved')
                with open(log_path, 'a') as f:
                    f.write('Model saved\n')

            with open(log_path, 'a') as f:
                f.write('\n')
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            ax.plot(losses)
            plt.savefig(os.path.join(ne2ceCT_path, 'losses.png'))


        dataloader.dataset.reset_patch_count()
        gc.collect()
        # clear cuda cache
        torch.cuda.empty_cache()
        dist.barrier()



if __name__ == '__main__':
    main()
